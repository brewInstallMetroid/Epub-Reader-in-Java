package edu.unomaha.epubreader.model;

class EpubBook {
}
